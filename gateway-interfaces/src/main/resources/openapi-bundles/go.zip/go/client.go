// Agent Gateway Go SDK - Round 10 Placeholder client.
//
// Minimal demo: call GET /v1/health and print the result.
// Replace this file with the real SDK once Round 11 PR lands.
package main

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
)

type HealthResponse struct {
	Status string `json:"status"`
	Uptime int64  `json:"uptime,omitempty"`
}

func baseURL() string {
	if v := os.Getenv("GATEWAY_BASE_URL"); v != "" {
		return v
	}
	return "http://localhost:8080"
}

func apiKey() string {
	if v := os.Getenv("GATEWAY_API_KEY"); v != "" {
		return v
	}
	return "sk-demo-primary-0001"
}

func Health() (*HealthResponse, error) {
	req, err := http.NewRequest(http.MethodGet, baseURL()+"/v1/health", nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("X-API-Key", apiKey())
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("health HTTP %d", resp.StatusCode)
	}
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	var out HealthResponse
	if err := json.Unmarshal(body, &out); err != nil {
		return nil, err
	}
	return &out, nil
}

func main() {
	r, err := Health()
	if err != nil {
		fmt.Fprintln(os.Stderr, "FAIL:", err)
		os.Exit(1)
	}
	fmt.Println("OK:", r)
}

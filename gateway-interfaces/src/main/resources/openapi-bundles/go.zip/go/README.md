# Agent Gateway Go SDK (Round 10 Placeholder)

> **注意**：这是 Round 10 的占位 SDK，包含 1 个示例方法 `Health()`。
> 真实完整 SDK（所有端点 + Go structs）将由 Round 11 PR 通过 `openapi-generator-cli` 自动生成后替换此 zip。

## 接入（临时）

```bash
unzip agent-gateway-go-sdk.zip -d agent-gateway-sdk
cd agent-gateway-sdk
go mod tidy
go run client.go
```

## 接入（Round 11 完整版预期）

```bash
go get github.com/company/agent-gateway-sdk
import gateway "github.com/company/agent-gateway-sdk"
client := gateway.NewClient("sk-...", "https://your-gateway")
resp, err := client.Chat.Completions.Create(ctx, ...)
```

## 反馈

内部 GitLab issue：tag `round11-sdk`，@platform-team 负责生成 pipeline。

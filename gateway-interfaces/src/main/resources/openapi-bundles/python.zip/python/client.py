"""Agent Gateway Python SDK - Round 10 Placeholder client.

Minimal demo: call GET /v1/health and print the result.
Replace this file with the real SDK once Round 11 PR lands.
"""
import os
import sys

import requests

BASE_URL = os.environ.get("GATEWAY_BASE_URL", "http://localhost:8080")
API_KEY = os.environ.get("GATEWAY_API_KEY", "sk-demo-primary-0001")


def health() -> dict:
    """Call GET /v1/health on the gateway."""
    resp = requests.get(
        f"{BASE_URL}/v1/health",
        headers={"X-API-Key": API_KEY},
        timeout=10,
    )
    resp.raise_for_status()
    return resp.json()


if __name__ == "__main__":
    try:
        result = health()
        print(f"OK: {result}")
        sys.exit(0)
    except Exception as exc:  # noqa: BLE001
        print(f"FAIL: {exc}", file=sys.stderr)
        sys.exit(1)

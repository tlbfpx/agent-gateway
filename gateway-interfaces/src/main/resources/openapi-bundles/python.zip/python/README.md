# Agent Gateway Python SDK (Round 10 Placeholder)

> **注意**：这是 Round 10 的占位 SDK，包含 1 个示例方法 `health()`。
> 真实完整 SDK（所有端点 + pydantic 模型）将由 Round 11 PR 通过 `openapi-generator-cli` 自动生成后替换此 zip。

## 接入（临时）

```bash
unzip agent-gateway-python-sdk.zip -d agent-gateway-sdk
cd agent-gateway-sdk
pip install requests
python client.py
```

## 接入（Round 11 完整版预期）

```bash
pip install agent-gateway-sdk
from agent_gateway import AgentGateway
client = AgentGateway(api_key="sk-...", base_url="https://your-gateway")
client.chat.completions.create(model="gpt-4o", messages=[...])
```

## 反馈

内部 GitLab issue：tag `round11-sdk`，@platform-team 负责生成 pipeline。

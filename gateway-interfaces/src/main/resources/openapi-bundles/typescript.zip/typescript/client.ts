/**
 * Agent Gateway TypeScript SDK - Round 10 Placeholder client.
 *
 * Minimal demo: call GET /v1/health and print the result.
 * Replace this file with the real SDK once Round 11 PR lands.
 */

const BASE_URL = process.env.GATEWAY_BASE_URL ?? 'http://localhost:8080';
const API_KEY = process.env.GATEWAY_API_KEY ?? 'sk-demo-primary-0001';

interface HealthResponse {
  status: string;
  uptime?: number;
}

export async function health(): Promise<HealthResponse> {
  const res = await fetch(`${BASE_URL}/v1/health`, {
    headers: { 'X-API-Key': API_KEY },
  });
  if (!res.ok) {
    throw new Error(`health HTTP ${res.status}`);
  }
  return (await res.json()) as HealthResponse;
}

if (require.main === module) {
  health()
    .then((r) => {
      // eslint-disable-next-line no-console
      console.log('OK:', r);
      process.exit(0);
    })
    .catch((err: unknown) => {
      // eslint-disable-next-line no-console
      console.error('FAIL:', err);
      process.exit(1);
    });
}

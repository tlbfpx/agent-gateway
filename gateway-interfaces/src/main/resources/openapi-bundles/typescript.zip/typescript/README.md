# Agent Gateway TypeScript SDK (Round 10 Placeholder)

> **注意**：这是 Round 10 的占位 SDK，包含 1 个示例方法 `health()`。
> 真实完整 SDK（所有端点 + 类型定义）将由 Round 11 PR 通过 `openapi-generator-cli` 自动生成后替换此 zip。

## 接入（临时）

```bash
unzip agent-gateway-typescript-sdk.zip -d agent-gateway-sdk
cd agent-gateway-sdk
npm install
npx ts-node client.ts
```

## 接入（Round 11 完整版预期）

```bash
npm install @agent-gateway/sdk
import { AgentGateway } from '@agent-gateway/sdk';
const client = new AgentGateway({ apiKey: 'sk-...', baseUrl: 'https://your-gateway' });
await client.chat.completions.create({ model: 'gpt-4o', messages: [...] });
```

## 反馈

内部 GitLab issue：tag `round11-sdk`，@platform-team 负责生成 pipeline。
